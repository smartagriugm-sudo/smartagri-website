// Data simulasi growth chamber. SEMUA ANGKA DI SINI CONTOH, belum tersambung ke alat atau ERP.

// plant: tinggi kecambah relatif. plugs: media semai terlihat. lid: nampan ditutup nampan lain, seperti pada foto.
export const SEED_STATES = {
  kosong: { label: 'Kosong', color: 0x8d9398, plant: 0, plugs: false, lid: false },
  disemai: { label: 'Baru disemai', color: 0xc9a26a, plant: 0, plugs: true, lid: true },
  berkecambah: { label: 'Berkecambah', color: 0xa5d66b, plant: 0.6, plugs: true, lid: false },
  siap_pindah: { label: 'Siap pindah tanam', color: 0x2f9e57, plant: 1.05, plugs: true, lid: false },
  masalah: { label: 'Bermasalah', color: 0xd9433b, plant: 0.5, plugs: true, lid: false },
};

// warna nampan pada foto
export const TRAY_COLORS = { hijau: 0x7cc528, merah: 0xd31f2a, biru: 0x1c3fc0, ungu: 0x6d4fd0 };

const addDays = (date, n) => {
  const d = new Date(date + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
};

export class SimulatedChamberProvider {
  constructor(manifest) {
    this.slots = new Map();
    const plan = {
      1: ['siap_pindah', '2026-10-21', ['hijau', 'hijau', 'merah', 'hijau', 'hijau', 'biru']],
      2: ['berkecambah', '2026-10-29', ['hijau', 'merah', 'hijau', 'ungu', 'merah', 'hijau']],
      3: ['disemai', '2026-11-03', ['merah', 'hijau', 'ungu', 'hijau', 'hijau', 'merah']],
      4: ['berkecambah', '2026-10-31', ['hijau', 'ungu', 'merah', 'hijau']],
    };
    for (const s of manifest.slots) {
      const [planned, sownOn, colors] = plan[s.shelf];
      // baris belakang rak bawah kosong, satu posisi diberi masalah sebagai contoh
      const state = s.shelf === 3 && s.row === 3 ? 'kosong' : s.shelf === 2 && s.position === 3 ? 'masalah' : planned;
      const empty = state === 'kosong';
      this.slots.set(s.id, {
        state,
        trayColor: colors[s.position - 1],
        batch: empty ? '' : `SMI-2026-${String(s.shelf).padStart(3, '0')}`,
        crop: empty ? '' : 'Selada',
        sownOn: empty ? '' : sownOn,
        seedCount: empty ? 0 : 20,
        germinated: state === 'berkecambah' ? 17 : state === 'siap_pindah' ? 18 : state === 'masalah' ? 6 : 0,
        transplantOn: empty ? '' : addDays(sownOn, 14),
        note: '',
      });
    }
    this.lamps = new Map();
    for (const o of manifest.objects) {
      if (o.type === 'lamp') this.lamps.set(o.id, true);
    }
  }

  getSlot(id) { return this.slots.get(id); }
  updateSlot(id, patch) { Object.assign(this.slots.get(id), patch); }
  setLamp(id, on) { this.lamps.set(id, on); }

  readings(t = Date.now() / 1000) {
    const w = (period, amp) => Math.sin((t / period) * Math.PI * 2) * amp;
    return {
      suhu: { label: 'Suhu', value: 24 + w(90, 0.3), unit: '°C', d: 1 },
      rh: { label: 'Kelembapan', value: 72 + w(120, 2.5), unit: '% RH', d: 0 },
      lux: { label: 'Pencahayaan', value: 12000 + w(70, 150), unit: 'lux', d: 0 },
    };
  }
}
