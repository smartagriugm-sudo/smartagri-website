// Mesin 3D growth chamber FPG450, tanpa antarmuka. Lihat README.md untuk panduan integrasi.
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { RectAreaLightUniformsLib } from 'three/addons/lights/RectAreaLightUniformsLib.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { GTAOPass } from 'three/addons/postprocessing/GTAOPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { SEED_STATES, SimulatedChamberProvider, TRAY_COLORS } from './chamber-data.js';

export { SEED_STATES, SimulatedChamberProvider, TRAY_COLORS };

const LED_WHITE = 0xfff6ea;             // full spectrum, tampak dominan putih saat menyala
// ukuran nampan diperkirakan dari foto: dua nampan mengisi lebar rak
const TRAY = { w: 0.272, d: 0.196, h: 0.036 };
const PLUG_COLS = 5, PLUG_ROWS = 4, PLUGS_PER_SLOT = PLUG_COLS * PLUG_ROWS;
const PLUG_FLOOR = 0.005;
const DEFAULT_ASSETS = new URL('../assets/', import.meta.url);
const eachMesh = (o, fn) => o?.traverse((c) => { if (c.isMesh) fn(c); });

function brushedTexture() {
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const g = c.getContext('2d');
  g.fillStyle = 'rgb(170,170,170)';
  g.fillRect(0, 0, 256, 256);
  let s = 61;
  const r = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  for (let i = 0; i < 600; i++) {
    const v = 110 + r() * 130;
    g.strokeStyle = `rgba(${v},${v},${v},0.3)`;
    g.lineWidth = 0.5 + r();
    const y = r() * 256;
    g.beginPath(); g.moveTo(0, y); g.lineTo(256, y); g.stroke();
  }
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(1, 8);
  t.anisotropy = 8;
  return t;
}

// Permukaan dari beberapa irisan persegi bersudut bulat: [setengah lebar, setengah dalam, jari-jari, tinggi].
function loftGeometry(rings, { capStart = false, capEnd = false } = {}) {
  const segs = 5, perRing = (segs + 1) * 4, pos = [], idx = [];
  for (const [hw, hd, r, y] of rings) {
    for (let c = 0; c < 4; c++) {
      const cx = (c === 0 || c === 3) ? hw - r : -(hw - r), cz = c < 2 ? hd - r : -(hd - r);
      for (let i = 0; i <= segs; i++) {
        const a = (c + i / segs) * Math.PI / 2;
        pos.push(cx + r * Math.cos(a), y, cz + r * Math.sin(a));
      }
    }
  }
  for (let k = 0; k < rings.length - 1; k++) {
    for (let i = 0; i < perRing; i++) {
      const j = (i + 1) % perRing, a = k * perRing + i, b = k * perRing + j, up = a + perRing, upj = b + perRing;
      idx.push(a, up, b, b, up, upj);
    }
  }
  const cap = (ring, y, start) => {
    const c = pos.length / 3;
    pos.push(0, y, 0);
    for (let i = 0; i < perRing; i++) {
      const a = ring * perRing + i, b = ring * perRing + (i + 1) % perRing;
      if (start) idx.push(c, a, b); else idx.push(a, c, b);
    }
  };
  if (capStart) cap(0, rings[0][3], true);
  if (capEnd) cap(rings.length - 1, rings[rings.length - 1][3], false);
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

// Nampan plastik dari foto: dinding melebar ke atas, bibir bergulung, sudut bulat, tanda cetak bundar di lantainya.
function trayGeometry() {
  const W = TRAY.w / 2, D = TRAY.d / 2, h = TRAY.h;
  const shell = loftGeometry([
    [W - 0.017, D - 0.017, 0.016, 0],
    [W - 0.012, D - 0.012, 0.019, 0.002],
    [W - 0.006, D - 0.006, 0.024, h - 0.008],
    [W - 0.001, D - 0.001, 0.027, h - 0.004],
    [W, D, 0.028, h - 0.0015],
    [W - 0.0015, D - 0.0015, 0.0275, h],
    [W - 0.006, D - 0.006, 0.0245, h],
    [W - 0.008, D - 0.008, 0.023, h - 0.002],
    [W - 0.018, D - 0.018, 0.016, 0.009],
    [W - 0.023, D - 0.023, 0.012, 0.0035],
    [W - 0.028, D - 0.028, 0.008, 0.0025],
  ], { capStart: true, capEnd: true });
  const marks = [[-0.075, -0.045], [0.08, 0.04], [0.075, -0.05], [-0.08, 0.05]].map(([x, z]) => {
    const m = new THREE.CylinderGeometry(0.009, 0.0095, 0.0006, 16).translate(x, 0.0028, z);
    m.deleteAttribute('uv');
    return m;
  });
  shell.deleteAttribute('uv');
  return mergeGeometries([shell, ...marks]);
}

function trayOutlineGeometry() {
  const W = TRAY.w / 2 + 0.005, D = TRAY.d / 2 + 0.005;
  return loftGeometry([
    [W, D, 0.032, 0], [W, D, 0.032, 0.003],
    [W - 0.009, D - 0.009, 0.026, 0.003], [W - 0.009, D - 0.009, 0.026, 0],
  ]);
}

// Kecambah selada: batang pucat, dua daun lembaga, dan dua daun sejati kecil di tengah.
function sproutGeometry() {
  const paint = (g, r, gg, b) => {
    const n = g.attributes.position.count, col = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) { col[i * 3] = r; col[i * 3 + 1] = gg; col[i * 3 + 2] = b; }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    return g;
  };
  const leaf = (angle, len, wid, y0, lift, droop, shade) => {
    const rows = 5, cols = 2, pos = [], col = [], idx = [];
    for (let i = 0; i <= rows; i++) {
      const t = i / rows, half = wid * Math.pow(Math.sin(Math.PI * Math.pow(t, 0.72)), 0.8);
      for (let j = 0; j <= cols; j++) {
        const u = j / cols * 2 - 1;
        pos.push(len * t, y0 + lift * Math.sin(t * Math.PI * 0.6) - droop * t * t + Math.abs(u) * half * 0.28, u * half);
        const v = shade * (1.08 - 0.14 * t - 0.1 * Math.abs(u));
        col.push(v, v, v * 0.82);
      }
    }
    for (let i = 0; i < rows; i++) for (let j = 0; j < cols; j++) {
      const a = i * (cols + 1) + j, b = a + 1, c = a + cols + 1, d = c + 1;
      idx.push(a, c, b, b, c, d);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    g.setIndex(idx);
    g.rotateY(angle);
    g.computeVertexNormals();
    return g;
  };
  const stem = new THREE.CylinderGeometry(0.0009, 0.0013, 0.034, 5, 1, true).translate(0, 0.017, 0);
  stem.deleteAttribute('uv');
  paint(stem, 1.0, 1.0, 0.72);
  return mergeGeometries([
    stem,
    leaf(0, 0.019, 0.0065, 0.033, 0.006, 0.006, 0.86), leaf(Math.PI, 0.019, 0.0065, 0.033, 0.006, 0.006, 0.86),
    leaf(Math.PI / 2, 0.015, 0.0055, 0.034, 0.012, 0.002, 0.72), leaf(-Math.PI / 2, 0.012, 0.0045, 0.034, 0.011, 0.001, 0.7),
  ]);
}

// Label kertas pada dinding depan nampan, seperti pada foto.
function paperTexture() {
  const c = document.createElement('canvas');
  c.width = 256; c.height = 96;
  const g = c.getContext('2d');
  g.fillStyle = '#fbfaf5'; g.fillRect(0, 0, 256, 96);
  g.strokeStyle = 'rgba(40,40,60,.6)'; g.lineWidth = 3; g.lineCap = 'round';
  for (const [y, end] of [[34, 226], [62, 170]]) {
    g.beginPath(); g.moveTo(66, y);
    for (let x = 66; x < end; x += 9) g.lineTo(x, y + Math.sin(x * 0.7) * 4);
    g.stroke();
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function blobTexture() {
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const g = c.getContext('2d');
  const grad = g.createRadialGradient(64, 64, 26, 64, 64, 64);
  grad.addColorStop(0, 'rgba(0,0,0,.55)');
  grad.addColorStop(0.7, 'rgba(0,0,0,.34)');
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = grad;
  g.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(c);
}

export async function createSeedChamberScene(options = {}) {
  const { container, assetsUrl = DEFAULT_ASSETS, provider: providerOption, slotStates = SEED_STATES, quality = 'auto', tooltip = true } = options;
  if (!(container instanceof HTMLElement)) throw new Error('createSeedChamberScene: container harus elemen HTML');
  if (getComputedStyle(container).position === 'static') container.style.position = 'relative';

  const base = new URL(String(assetsUrl).replace(/\/?$/, '/'), location.href);
  const modelUrl = options.modelUrl || new URL('seed_chamber.glb', base).href;
  const manifestUrl = options.manifestUrl || new URL('seed_chamber_manifest.json', base).href;

  const listeners = new Map();
  const emit = (type, payload) => { for (const fn of listeners.get(type) || []) fn(payload); };
  const dom = new AbortController();

  const [gltf, manifest] = await Promise.all([
    new GLTFLoader().loadAsync(modelUrl),
    fetch(manifestUrl).then((r) => { if (!r.ok) throw new Error('manifest ' + r.status); return r.json(); }),
  ]);
  const provider = typeof providerOption === 'function' ? providerOption(manifest) : (providerOption || new SimulatedChamberProvider(manifest));
  if (typeof provider.getSlot !== 'function' || typeof provider.lamps?.get !== 'function') {
    throw new Error('Provider harus memiliki getSlot(id) dan lamps.get(id)');
  }

  const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.NeutralToneMapping;
  renderer.domElement.style.cssText += ';position:absolute;inset:0;width:100%;height:100%;display:block';
  container.prepend(renderer.domElement);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0xe7eae7);
  const camera = new THREE.PerspectiveCamera(36, 1, 0.03, 40);
  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.08;
  controls.maxPolarAngle = Math.PI * 0.6;
  controls.minDistance = 0.25;
  controls.maxDistance = 9;
  RectAreaLightUniformsLib.init();

  const pmrem = new THREE.PMREMGenerator(renderer);
  scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  const hemi = new THREE.HemisphereLight(0xffffff, 0xe4e6e3, 1.4);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xffffff, 0.9);
  sun.position.set(-1.8, 5, 3.2);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  Object.assign(sun.shadow.camera, { left: -2.5, right: 2.5, top: 3, bottom: -2, near: 0.5, far: 12 });
  sun.shadow.bias = -0.0004;
  sun.shadow.normalBias = 0.008;
  sun.shadow.radius = 6;
  sun.target.position.set(0, 0.8, -0.5);
  scene.add(sun, sun.target);

  const floor = new THREE.Mesh(new THREE.PlaneGeometry(30, 30), new THREE.ShadowMaterial({ opacity: 0.18 }));
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);

  const composer = new EffectComposer(renderer, new THREE.WebGLRenderTarget(1, 1, { type: THREE.HalfFloatType, samples: 4 }));
  composer.addPass(new RenderPass(scene, camera));
  const gtao = new GTAOPass(scene, camera, 1, 1);
  gtao.blendIntensity = 0.8;
  gtao.updateGtaoMaterial({ radius: 0.09, distanceExponent: 1.2, thickness: 1, scale: 1.2, samples: 16, distanceFallOff: 1, screenSpaceRadius: false });
  gtao.updatePdMaterial({ lumaPhi: 10, depthPhi: 2, normalPhi: 3, radius: 5, radiusExponent: 1, rings: 2, samples: 16 });
  const baseOverride = gtao.overrideVisibility.bind(gtao);
  gtao.overrideVisibility = function () {
    baseOverride();
    this.scene.traverse((o) => { if (o.isMesh && (o.material.transparent || o.material.isShadowMaterial)) o.visible = false; });
  };
  composer.addPass(gtao);
  composer.addPass(new OutputPass());

  let highQuality = quality === 'auto' ? innerWidth >= 980 : !!quality;
  let qualityTouched = quality !== 'auto';
  let realLight = false;
  let outerOpen = true;
  let glassOpen = true;
  let statusColors = false;
  let filter = { shelf: 0 };
  let selected = null;
  let hovered = -1;
  let currentView = 'overview';

  const getOptions = () => ({ doorsOpen: outerOpen && glassOpen, outerDoorOpen: outerOpen, glassDoorOpen: glassOpen, statusColors, realLight, highQuality });

  // ---------------------------------------------------------------- model
  scene.add(gltf.scene);
  const nodes = new Map();
  gltf.scene.traverse((o) => { if (o.name) nodes.set(o.name, o); });
  const metal = brushedTexture();
  const seenMats = new Set();
  eachMesh(gltf.scene, (m) => {
    m.castShadow = true;
    m.receiveShadow = true;
    const mat = m.material;
    if (mat.name === 'mat_glass') m.castShadow = false;
    if (seenMats.has(mat)) return;
    seenMats.add(mat);
    if (['mat_steel', 'mat_liner', 'mat_grille'].includes(mat.name)) { mat.roughnessMap = metal; mat.roughness = 0.5; mat.envMapIntensity = 1.9; }
    if (mat.name === 'mat_glass') {
      Object.assign(mat, { transparent: true, opacity: 0.13, roughness: 0.04, metalness: 0, depthWrite: false, envMapIntensity: 2 });
    }
    mat.needsUpdate = true;
  });

  // pintu berputar pada engsel masing-masing
  const pivots = {};
  for (const [key, d] of Object.entries(manifest.doors)) {
    const p = new THREE.Group();
    p.position.set(...d.pivot);
    scene.add(p);
    for (const name of d.nodes) {
      const n = nodes.get(name);
      if (!n) throw new Error('Node hilang di GLB: ' + name);
      p.attach(n);
    }
    pivots[key] = { group: p, max: THREE.MathUtils.degToRad(d.open_deg), t: 1 };
  }

  // layar sentuh menampilkan bacaan dari provider
  const hmiCanvas = document.createElement('canvas');
  hmiCanvas.width = 512; hmiCanvas.height = 310;
  const hmiTex = new THREE.CanvasTexture(hmiCanvas);
  hmiTex.colorSpace = THREE.SRGBColorSpace;
  eachMesh(nodes.get('hmi_screen'), (mesh) => {
    const pos = mesh.geometry.attributes.position;
    const box = new THREE.Box3().setFromBufferAttribute(pos);
    const uv = new Float32Array(pos.count * 2);
    for (let i = 0; i < pos.count; i++) {
      uv[i * 2] = (pos.getX(i) - box.min.x) / (box.max.x - box.min.x);
      uv[i * 2 + 1] = (pos.getY(i) - box.min.y) / (box.max.y - box.min.y);
    }
    mesh.geometry.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    mesh.material = new THREE.MeshStandardMaterial({ map: hmiTex, emissiveMap: hmiTex, emissive: 0xffffff, emissiveIntensity: 0.9, roughness: 0.25 });
    mesh.castShadow = false;
  });
  function drawHmi() {
    const g = hmiCanvas.getContext('2d');
    g.fillStyle = '#0d1f2a'; g.fillRect(0, 0, 512, 310);
    g.fillStyle = '#12695f'; g.fillRect(0, 0, 512, 44);
    g.fillStyle = '#fff'; g.font = '600 24px Arial, sans-serif'; g.textBaseline = 'middle'; g.textAlign = 'left';
    g.fillText(manifest.chamber.model, 16, 23);
    const r = provider.readings?.();
    const items = r ? Object.values(r) : [];
    items.slice(0, 3).forEach((m, i) => {
      const y = 62 + i * 82;
      g.fillStyle = '#163444'; g.fillRect(14, y, 484, 72);
      g.fillStyle = '#9fc4cf'; g.font = '22px Arial, sans-serif'; g.textAlign = 'left';
      g.fillText(m.label, 28, y + 36);
      g.fillStyle = '#fff'; g.font = '700 38px Arial, sans-serif'; g.textAlign = 'right';
      g.fillText(`${m.value.toFixed(m.d)} ${m.unit}`, 484, y + 37);
    });
    if (!items.length) { g.fillStyle = '#9fc4cf'; g.font = '26px Arial, sans-serif'; g.textAlign = 'center'; g.fillText('Belum ada data', 256, 170); }
    hmiTex.needsUpdate = true;
  }

  // ---------------------------------------------------------------- lampu dan objek
  const lampMats = new Map(), lampLights = new Map(), pcbMats = new Map(), pickableObjects = [], objectIds = new Set();
  for (const o of manifest.objects) {
    objectIds.add(o.id);
    const node = nodes.get(o.node);
    if (!node) throw new Error('Node hilang di GLB: ' + o.node);
    node.userData.objectId = o.id;
    pickableObjects.push(node);
    for (const h of o.hosts || []) {
      const host = nodes.get(h);
      if (!host) throw new Error('Node hilang di GLB: ' + h);
      host.userData.objectId = o.id;
      pickableObjects.push(host);
    }
    if (o.type === 'lamp') {
      const led = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: LED_WHITE, emissiveIntensity: 0, toneMapped: false });
      const pcb = new THREE.MeshStandardMaterial({ color: 0xedeee8, emissive: LED_WHITE, emissiveIntensity: 0, roughness: 0.45 });
      eachMesh(node, (m) => {
        m.castShadow = false;
        if (m.material.name === 'mat_led') m.material = led;
        if (m.material.name === 'mat_pcb') m.material = pcb;
      });
      lampMats.set(o.id, led);
      pcbMats.set(o.id, pcb);
      const light = new THREE.RectAreaLight(LED_WHITE, 0, manifest.bounds.interior.width - 0.08, manifest.bounds.interior.depth - 0.1);
      light.position.set(o.pos[0], o.pos[1], o.pos[2]);
      light.lookAt(o.pos[0], 0, o.pos[2]);
      scene.add(light);
      lampLights.set(o.id, light);
    }
  }

  function applyLighting() {
    hemi.intensity = realLight ? 0.12 : 1.4;
    sun.intensity = realLight ? 0 : 0.9;
    scene.environmentIntensity = realLight ? 0.05 : 0.45;
    floor.visible = !realLight;
    scene.background.set(realLight ? 0x14171a : 0xe7eae7);
    for (const [id, led] of lampMats) {
      const on = !!provider.lamps.get(id);
      led.emissiveIntensity = on ? 1.6 : 0;
      led.color.set(on ? 0xffffff : 0xb9bbb6);
      pcbMats.get(id).emissiveIntensity = on ? (realLight ? 0.9 : 0.55) : 0;
      lampLights.get(id).intensity = on ? (realLight ? 2.6 : 1.5) : 0;
    }
    gtao.enabled = highQuality;
  }

  // ---------------------------------------------------------------- posisi semai
  const slots = manifest.slots;
  const slotIndex = new Map(slots.map((s, i) => [s.id, i]));
  const shelfOf = new Map(manifest.shelves.map((s) => [s.shelf, s]));

  const plastic = () => new THREE.MeshPhysicalMaterial({ roughness: 0.3, clearcoat: 0.7, clearcoatRoughness: 0.18, envMapIntensity: 1.3 });
  const trayGeo = trayGeometry();
  const trayMesh = new THREE.InstancedMesh(trayGeo, plastic(), slots.length);
  const lidMesh = new THREE.InstancedMesh(trayGeo, plastic(), slots.length);
  const blobMesh = new THREE.InstancedMesh(new THREE.PlaneGeometry(TRAY.w + 0.03, TRAY.d + 0.03).rotateX(-Math.PI / 2),
    new THREE.MeshBasicMaterial({ map: blobTexture(), transparent: true, depthWrite: false }), slots.length);
  const paperMesh = new THREE.InstancedMesh(new THREE.BoxGeometry(0.084, 0.022, 0.0008),
    new THREE.MeshStandardMaterial({ map: paperTexture(), roughness: 0.85 }), slots.length);
  const stripeMesh = new THREE.InstancedMesh(new THREE.BoxGeometry(0.018, 0.022, 0.001), new THREE.MeshBasicMaterial({ toneMapped: false }), slots.length);
  const outlineMesh = new THREE.InstancedMesh(trayOutlineGeometry(), new THREE.MeshBasicMaterial({ toneMapped: false, side: THREE.DoubleSide }), slots.length);
  // media semai: kubus lembap dengan lekuk tempat benih
  const plugMesh = new THREE.InstancedMesh(new THREE.BoxGeometry(0.036, 0.016, 0.032).translate(0, 0.008, 0),
    new THREE.MeshStandardMaterial({ roughness: 0.95 }), slots.length * PLUGS_PER_SLOT);
  const sproutMesh = new THREE.InstancedMesh(sproutGeometry(), new THREE.MeshStandardMaterial({ roughness: 0.55, vertexColors: true, side: THREE.DoubleSide }), slots.length * PLUGS_PER_SLOT);
  const allInstanced = [blobMesh, trayMesh, lidMesh, paperMesh, stripeMesh, outlineMesh, plugMesh, sproutMesh];
  for (const m of allInstanced) {
    m.frustumCulled = false;
    m.castShadow = m === trayMesh || m === lidMesh || m === sproutMesh;
    m.receiveShadow = m !== blobMesh && m !== outlineMesh && m !== stripeMesh;
    scene.add(m);
  }
  blobMesh.renderOrder = 1;

  const _m = new THREE.Matrix4(), _p = new THREE.Vector3(), _q = new THREE.Quaternion(), _s = new THREE.Vector3(), _c = new THREE.Color();
  const _y = new THREE.Vector3(0, 1, 0);
  const _x = new THREE.Vector3(1, 0, 0);
  const _zero = new THREE.Vector3(0, 0, 0), _one = new THREE.Vector3(1, 1, 1);
  const slotVisible = (s) => !filter.shelf || s.shelf === filter.shelf;
  const trayHex = (data, st, i) => {
    if (statusColors) return st.color;
    const c = data.trayColor;
    if (typeof c === 'number') return c;
    return TRAY_COLORS[c] ?? [TRAY_COLORS.hijau, TRAY_COLORS.merah, TRAY_COLORS.ungu][i % 3];
  };

  function refreshSlot(i) {
    const s = slots[i];
    const data = provider.getSlot(s.id) || { state: 'kosong' };
    const st = slotStates[data.state] || slotStates.kosong;
    const vis = slotVisible(s);
    const isSel = selected?.kind === 'slot' && selected.id === s.id;
    const isHover = hovered === i;
    const showIf = (c) => (vis && c ? _one : _zero);
    const [sx, sy, sz] = s.pos;
    const tip = (i % 7 - 3) * 0.008;   // nampan tidak diletakkan persis lurus

    _q.setFromAxisAngle(_y, tip);
    _p.set(sx, sy, sz);
    trayMesh.setMatrixAt(i, _m.compose(_p, _q, showIf(true)));
    trayMesh.setColorAt(i, _c.setHex(trayHex(data, st, i)));

    _p.set(sx, sy + 0.0012, sz);
    blobMesh.setMatrixAt(i, _m.compose(_p, _q, showIf(true)));

    // penutup: nampan lain dibalik, bibirnya bertemu bibir nampan bawah
    _p.set(sx, sy + TRAY.h * 2 + 0.0015, sz);
    _q.setFromAxisAngle(_x, Math.PI);
    lidMesh.setMatrixAt(i, _m.compose(_p, _q, showIf(st.lid)));
    lidMesh.setColorAt(i, _c.setHex(statusColors ? st.color : TRAY_COLORS.hijau));

    // label kertas menempel miring mengikuti dinding depan
    _q.setFromAxisAngle(_x, 0.2);
    _p.set(sx, sy + TRAY.h * 0.5, sz + TRAY.d / 2 - 0.0028);
    paperMesh.setMatrixAt(i, _m.compose(_p, _q, showIf(true)));
    _p.set(sx - 0.033, sy + TRAY.h * 0.5, sz + TRAY.d / 2 - 0.0026);
    stripeMesh.setMatrixAt(i, _m.compose(_p, _q, showIf(true)));
    stripeMesh.setColorAt(i, _c.setHex(st.color));

    // garis pilih hanya muncul saat diarahkan atau dipilih
    _p.set(sx, sy + TRAY.h + (st.lid ? TRAY.h + 0.003 : 0.0006), sz);
    outlineMesh.setMatrixAt(i, _m.compose(_p, _q.identity(), showIf(isSel || isHover)));
    outlineMesh.setColorAt(i, _c.setHex(isSel ? 0x12a5ff : 0xffffff));

    const ratio = data.seedCount ? Math.min(1, (data.germinated ?? data.seedCount) / data.seedCount) : (data.germinated == null ? 1 : 0);
    const grownCount = Math.round(ratio * PLUGS_PER_SLOT);
    for (let k = 0; k < PLUGS_PER_SLOT; k++) {
      const j = i * PLUGS_PER_SLOT + k;
      const col = k % PLUG_COLS, row = Math.floor(k / PLUG_COLS);
      const x = sx + (col - (PLUG_COLS - 1) / 2) * 0.0385, z = sz + (row - (PLUG_ROWS - 1) / 2) * 0.0345, y = sy + PLUG_FLOOR;
      _p.set(x, y, z);
      plugMesh.setMatrixAt(j, _m.compose(_p, _q.identity(), showIf(st.plugs)));
      const damp = ((j * 2971) % 89) / 89 * 0.05;
      _c.setHex(data.state === 'masalah' ? 0xa5966c : 0xd6cba2).offsetHSL(0, 0, damp - 0.025);
      plugMesh.setColorAt(j, _c);

      // urutan acak yang tetap per nampan, sehingga bibit yang gagal tersebar wajar
      const order = (k * 7 + i * 3) % PLUGS_PER_SLOT;
      const grown = vis && st.plant > 0 && order < grownCount;
      const v = 0.8 + ((j * 2654435761) >>> 0) / 4294967296 * 0.4;
      _p.set(x + ((j * 13) % 7 - 3) * 0.0008, y + 0.016, z + ((j * 17) % 7 - 3) * 0.0008);
      _q.setFromAxisAngle(_y, j * 2.399);
      _s.setScalar(grown ? st.plant * v * 1.3 : 0);
      sproutMesh.setMatrixAt(j, _m.compose(_p, _q, _s));
      _c.setHex(data.state === 'masalah' ? 0xb7a647 : data.state === 'berkecambah' ? 0x9fdc55 : 0x6cc44c);
      _c.offsetHSL(((j * 40503) % 97) / 97 * 0.03 - 0.015, 0, ((j * 2971) % 89) / 89 * 0.06 - 0.03);
      sproutMesh.setColorAt(j, _c);
    }
    for (const m of allInstanced) {
      m.instanceMatrix.needsUpdate = true;
      if (m.instanceColor) m.instanceColor.needsUpdate = true;
    }
  }
  const refreshAllSlots = () => slots.forEach((_, i) => refreshSlot(i));

  // ---------------------------------------------------------------- kamera + filter rak
  function shelfCamera(shelf) {
    const sh = shelfOf.get(shelf), b = manifest.bounds;
    const camZ = 0.72, back = -b.rackBack + camZ;
    // setinggi mungkin tanpa terhalang bibir atas bukaan
    const rise = Math.min(0.72, (b.openingTop - 0.03 - sh.y) * back / (camZ + 0.12 + (-b.rackBack - 0.12)));
    return { pos: [0, sh.y + rise, camZ], tgt: [0, sh.y + 0.02, (b.rackFront + b.rackBack) / 2], fov: 40 };
  }
  const viewPresets = () => ({
    overview: { pos: [-1.9, 1.7, 3.15], tgt: [0.14, 0.93, -0.28], fov: 36 },
    inside: { pos: [0, 1.2, 2.15], tgt: [0, 1.03, -0.4], fov: 36 },
  });
  function moveCamera(v) {
    camera.fov = v.fov;
    camera.updateProjectionMatrix();
    camera.position.set(...v.pos);
    controls.target.set(...v.tgt);
    // pada layar sempit kamera dimundurkan agar seluruh alat tetap masuk
    if (!filter.shelf && camera.aspect < 0.9) camera.position.sub(controls.target).multiplyScalar(0.9 / camera.aspect).add(controls.target);
    controls.update();
  }
  function setView(name) {
    const v = viewPresets()[name];
    if (!v) throw new Error('Tampilan tidak dikenal: ' + name);
    if (filter.shelf) { filter = { shelf: 0 }; applyFilter(); emit('filter', { ...filter }); }
    if (name === 'inside' && !(outerOpen && glassOpen)) setDoors(true);
    moveCamera(v);
    currentView = name;
    emit('view', name);
  }
  function applyFilter() {
    const sh = shelfOf.get(filter.shelf);
    for (const lv of [1, 2, 3, 4]) {
      // rak dan papan LED di atas rak terpilih disembunyikan agar isi rak terlihat
      const hide = sh && lv < sh.level;
      nodes.get(`level_l${lv}`).visible = !hide;
      nodes.get(`lamp_l${lv}`).visible = !hide;
    }
    refreshAllSlots();
  }
  function setFilter(next) {
    const shelf = next.shelf ?? filter.shelf;
    if (shelf && !shelfOf.has(shelf)) return false;
    filter = { shelf };
    applyFilter();
    if (shelf) {
      if (!(outerOpen && glassOpen)) setDoors(true);
      moveCamera(shelfCamera(shelf));
    } else moveCamera(viewPresets().inside);
    emit('filter', { ...filter });
    return true;
  }
  function setDoors(open) {
    outerOpen = glassOpen = !!open;
    emit('options', getOptions());
  }

  // ---------------------------------------------------------------- memilih
  const ray = new THREE.Raycaster();
  const ndc = new THREE.Vector2();
  const isVisibleChain = (o) => { for (; o; o = o.parent) if (!o.visible) return false; return true; };

  function pick(ev) {
    const r = renderer.domElement.getBoundingClientRect();
    ndc.set(((ev.clientX - r.left) / r.width) * 2 - 1, -((ev.clientY - r.top) / r.height) * 2 + 1);
    ray.setFromCamera(ndc, camera);
    const hits = ray.intersectObjects([trayMesh, lidMesh, sproutMesh, nodes.get('liner'), nodes.get('floor_grille'), ...[1, 2, 3, 4].map((l) => nodes.get(`level_l${l}`)), ...pickableObjects], true);
    for (const hit of hits) {
      if (hit.object === trayMesh || hit.object === lidMesh || hit.object === sproutMesh) {
        const i = hit.object === sproutMesh ? Math.floor(hit.instanceId / PLUGS_PER_SLOT) : hit.instanceId;
        if (slotVisible(slots[i])) return { kind: 'slot', index: i, id: slots[i].id };
        continue;
      }
      let o = hit.object;
      if (!isVisibleChain(o)) continue;
      while (o && !o.userData.objectId) o = o.parent;
      if (o) return { kind: 'object', id: o.userData.objectId };
      // rak dan dinding dalam menghalangi benda di belakangnya
      return null;
    }
    return null;
  }

  const tip = document.createElement('div');
  tip.style.cssText = 'position:absolute;display:none;background:rgba(20,26,24,.92);color:#fff;padding:3px 7px;border-radius:4px;font:12px system-ui,sans-serif;pointer-events:none;transform:translate(12px,12px);white-space:nowrap;z-index:5';
  if (tooltip) container.append(tip);

  function onMove(ev) {
    const p = pick(ev);
    const next = p?.kind === 'slot' ? p.index : -1;
    if (next !== hovered) {
      const prev = hovered;
      hovered = next;
      if (prev >= 0) refreshSlot(prev);
      if (next >= 0) refreshSlot(next);
    }
    renderer.domElement.style.cursor = p ? 'pointer' : 'grab';
    if (p) {
      const r = container.getBoundingClientRect();
      tip.style.display = 'block';
      tip.style.left = ev.clientX - r.left + 'px';
      tip.style.top = ev.clientY - r.top + 'px';
      tip.textContent = p.id;
    } else tip.style.display = 'none';
    emit('hover', p ? { kind: p.kind, id: p.id } : null);
  }

  let downAt = null;
  const signal = dom.signal;
  renderer.domElement.addEventListener('pointerdown', (e) => { downAt = [e.clientX, e.clientY]; }, { signal });
  renderer.domElement.addEventListener('pointerup', (e) => {
    if (!downAt || Math.hypot(e.clientX - downAt[0], e.clientY - downAt[1]) > 5) return;
    const p = pick(e);
    select(p ? { kind: p.kind, id: p.id } : null);
  }, { signal });
  renderer.domElement.addEventListener('pointermove', onMove, { signal });
  renderer.domElement.addEventListener('pointerleave', () => { tip.style.display = 'none'; }, { signal });

  function select(sel) {
    if (sel && !(sel.kind === 'slot' ? slotIndex.has(sel.id) : sel.kind === 'object' && objectIds.has(sel.id))) return false;
    const prev = selected;
    selected = sel ? { kind: sel.kind, id: sel.id } : null;
    if (prev?.kind === 'slot') refreshSlot(slotIndex.get(prev.id));
    if (selected?.kind === 'slot') refreshSlot(slotIndex.get(selected.id));
    emit('select', selected);
    return true;
  }
  function focusSlot(id) {
    const i = slotIndex.get(id);
    if (i === undefined) return false;
    setFilter({ shelf: slots[i].shelf });
    return select({ kind: 'slot', id });
  }
  function setOptions(next) {
    if ('doorsOpen' in next) outerOpen = glassOpen = !!next.doorsOpen;
    // pintu kaca berada di balik pintu besi: membuka kaca membuka besi, menutup besi menutup kaca
    if ('outerDoorOpen' in next) { outerOpen = !!next.outerDoorOpen; if (!outerOpen) glassOpen = false; }
    if ('glassDoorOpen' in next) { glassOpen = !!next.glassDoorOpen; if (glassOpen) outerOpen = true; }
    if ('statusColors' in next) { statusColors = !!next.statusColors; refreshAllSlots(); }
    if ('realLight' in next) realLight = !!next.realLight;
    if ('highQuality' in next) { highQuality = !!next.highQuality; qualityTouched = true; }
    applyLighting();
    emit('options', getOptions());
  }

  // ---------------------------------------------------------------- loop
  function resize() {
    const w = container.clientWidth, h = container.clientHeight;
    if (!w || !h) return;
    renderer.setSize(w, h, false);
    composer.setPixelRatio(renderer.getPixelRatio());
    composer.setSize(w, h);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  const resizeObserver = new ResizeObserver(resize);
  resizeObserver.observe(container);

  const perf = { last: 0, sum: 0, n: 0, avgMs: 0 };
  function watchPerformance(now) {
    const dt = now - perf.last;
    perf.last = now;
    if (dt <= 0 || dt > 500) return;
    perf.sum += dt;
    if (++perf.n < 90) return;
    perf.avgMs = perf.sum / perf.n;
    perf.sum = perf.n = 0;
    if (highQuality && !qualityTouched && perf.avgMs > 55) {
      highQuality = false;
      applyLighting();
      emit('options', getOptions());
    }
  }

  let lastDoorFrame = 0, lastHmi = 0;
  function tick(now) {
    watchPerformance(now);
    const dt = Math.min(0.1, (now - lastDoorFrame) / 1000 || 0);
    lastDoorFrame = now;
    // urutan seperti alat asli: buka besi dulu lalu kaca, tutup kaca dulu lalu besi
    const { outer, glass } = pivots;
    const swing = (d, target) => {
      if (d.t === target) return;
      d.t = Math.abs(target - d.t) < 0.002 ? target : d.t + (target - d.t) * Math.min(1, dt * 5);
      d.group.rotation.y = d.max * d.t;
    };
    swing(outer, outerOpen || glass.t > 0.04 ? 1 : 0);
    swing(glass, glassOpen ? (outer.t > 0.6 ? 1 : glass.t) : 0);
    if (now - lastHmi > 2000) { lastHmi = now; drawHmi(); }
    controls.update();
    composer.render();
  }

  for (const p of Object.values(pivots)) p.group.rotation.y = p.max * p.t;
  drawHmi();
  resize();
  refreshAllSlots();
  moveCamera(viewPresets().overview);
  applyLighting();
  renderer.setAnimationLoop(tick);

  let disposed = false;
  function dispose() {
    if (disposed) return;
    disposed = true;
    renderer.setAnimationLoop(null);
    dom.abort();
    resizeObserver.disconnect();
    controls.dispose();
    const seen = new Set();
    const free = (x) => { if (x && !seen.has(x)) { seen.add(x); x.dispose?.(); } };
    scene.traverse((o) => {
      free(o.geometry);
      if (o.isInstancedMesh) o.dispose();
      for (const m of [].concat(o.material || [])) {
        free(m);
        for (const v of Object.values(m)) if (v?.isTexture) free(v);
      }
    });
    scene.environment?.dispose();
    pmrem.dispose();
    composer.dispose();
    gtao.dispose();
    renderer.dispose();
    renderer.domElement.remove();
    tip.remove();
    listeners.clear();
  }

  return {
    manifest,
    provider,
    slotStates,
    get selected() { return selected; },
    get filter() { return { ...filter }; },
    get view() { return currentView; },
    get options() { return getOptions(); },
    setView,
    setFilter,
    setOptions,
    select,
    focusSlot,
    refreshSlot(id) { const i = slotIndex.get(id); if (i === undefined) return false; refreshSlot(i); return true; },
    refresh() { refreshAllSlots(); applyLighting(); drawHmi(); },
    on(type, fn) {
      if (!listeners.has(type)) listeners.set(type, new Set());
      listeners.get(type).add(fn);
      return () => listeners.get(type)?.delete(fn);
    },
    dispose,
    three: { THREE, scene, camera, renderer, controls, composer, gtao, nodes, perf },
  };
}
