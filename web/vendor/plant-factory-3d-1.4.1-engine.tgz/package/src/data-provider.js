// Data simulasi. SEMUA ANGKA DI SINI CONTOH, belum tersambung ke sensor atau ERP.
// Untuk integrasi, lihat README.md paket ini: buat provider sendiri dan berikan lewat opsi `provider`.

export const HOLE_STATES = {
  kosong: { label: 'Kosong', color: 0x8d9398, plant: 0 },
  semai: { label: 'Semai', color: 0xa5d66b, plant: 0.35 },
  vegetatif: { label: 'Vegetatif', color: 0x3fa652, plant: 0.75 },
  siap_panen: { label: 'Siap panen', color: 0xe0a526, plant: 1.05 },
  masalah: { label: 'Bermasalah', color: 0xd9433b, plant: 0.55 },
};

// pengacak dengan seed agar tampilan demo konsisten tiap dibuka
function rng(seed) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export class SimulatedProvider {
  constructor(manifest) {
    const r = rng(20261104);
    this.holes = new Map();
    for (const h of manifest.holes) {
      // satu batch per talang agar polanya masuk akal, bukan acak per lubang
      const batch = (h.rack * 7 + h.tier * 3 + h.gully) % 5;
      const state = ['vegetatif', 'siap_panen', 'semai', 'vegetatif', 'kosong'][batch];
      const final = state !== 'kosong' && r() < 0.03 ? 'masalah' : state;
      this.holes.set(h.id, {
        state: final,
        crop: final === 'kosong' ? '' : 'Selada',
        plantedOn: final === 'kosong' ? '' : `2026-10-${String(5 + batch * 4).padStart(2, '0')}`,
        note: '',
      });
    }
    this.lamps = new Map();
    this.pumps = new Map();
    for (const o of manifest.objects) {
      if (o.type === 'lamp') this.lamps.set(o.id, true);
      if (o.type === 'pump') this.pumps.set(o.id, true);
    }
  }

  getHole(id) { return this.holes.get(id); }
  updateHole(id, patch) { Object.assign(this.holes.get(id), patch); }
  setLamp(id, on) { this.lamps.set(id, on); }
  setPump(id, on) { this.pumps.set(id, on); }

  readings(t = Date.now() / 1000) {
    const w = (period, amp) => Math.sin((t / period) * Math.PI * 2) * amp;
    return {
      climate: {
        suhu: { label: 'Suhu udara', value: 24.2 + w(90, 0.4), unit: '°C', d: 1 },
        rh: { label: 'Kelembapan', value: 68 + w(120, 2), unit: '%', d: 0 },
        co2: { label: 'CO₂', value: 820 + w(150, 25), unit: 'ppm', d: 0 },
        ppfd: { label: 'PPFD', value: 210 + w(70, 4), unit: 'µmol/m²/s', d: 0 },
      },
      nutrient: {
        ph: { label: 'pH', value: 6.1 + w(200, 0.06), unit: '', d: 2 },
        ec: { label: 'EC', value: 1.8 + w(170, 0.04), unit: 'mS/cm', d: 2 },
        suhu: { label: 'Suhu larutan', value: 22.5 + w(240, 0.2), unit: '°C', d: 1 },
        level: { label: 'Level tandon', value: 74 + w(400, 1), unit: '%', d: 0 },
      },
    };
  }
}
