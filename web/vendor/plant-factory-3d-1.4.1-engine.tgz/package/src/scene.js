// Mesin 3D plant factory, tanpa antarmuka. Lihat README.md untuk panduan integrasi.
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { RectAreaLightUniformsLib } from 'three/addons/lights/RectAreaLightUniformsLib.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { GTAOPass } from 'three/addons/postprocessing/GTAOPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { HOLE_STATES, SimulatedProvider } from './data-provider.js';

export { HOLE_STATES, SimulatedProvider };

const LED_COLOR = 0xff3fcf;
const eachMesh = (o, fn) => o.traverse((c) => { if (c.isMesh) fn(c); });
const DEFAULT_ASSETS = new URL('../assets/', import.meta.url);

// ------------------------------------------------------------------ material dan tekstur
function canvasTexture(size, draw, repeatX, repeatY, srgb) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  draw(c.getContext('2d'), size);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeatX, repeatY);
  t.anisotropy = 8;
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
function mulberry(seed) {
  return () => {
    seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function speckle(lo, hi, seed) {
  return (g, n) => {
    const img = g.createImageData(n, n), r = mulberry(seed);
    for (let i = 0; i < img.data.length; i += 4) {
      const v = lo + (hi - lo) * r();
      img.data[i] = img.data[i + 1] = img.data[i + 2] = v;
      img.data[i + 3] = 255;
    }
    g.putImageData(img, 0, 0);
  };
}
// bercak lembut: beberapa lapis lingkaran buram, untuk lantai dan dinding
function mottle(base, range, seed, count) {
  return (g, n) => {
    const r = mulberry(seed);
    g.fillStyle = `rgb(${base},${base},${base})`;
    g.fillRect(0, 0, n, n);
    for (let i = 0; i < count; i++) {
      const x = r() * n, y = r() * n, rad = (0.03 + r() * 0.16) * n, v = base + (r() - 0.5) * range;
      for (const [ox, oy] of [[0, 0], [n, 0], [-n, 0], [0, n], [0, -n]]) {
        const grad = g.createRadialGradient(x + ox, y + oy, 0, x + ox, y + oy, rad);
        grad.addColorStop(0, `rgba(${v},${v},${v},0.32)`);
        grad.addColorStop(1, `rgba(${v},${v},${v},0)`);
        g.fillStyle = grad;
        g.fillRect(0, 0, n, n);
      }
    }
  };
}
// serat kayu sejajar sumbu V
function woodGrain(seed, strength = 1) {
  return (g, n) => {
    const r = mulberry(seed);
    g.fillStyle = '#ffffff';
    g.fillRect(0, 0, n, n);
    for (let i = 0; i < 420; i++) {
      const x = r() * n, w = 0.4 + r() * 2.2, a = (0.03 + r() * 0.14) * strength, sway = (r() - 0.5) * 26, ph = r() * 6.28;
      g.strokeStyle = `rgba(30,18,10,${a})`;
      g.lineWidth = w;
      g.beginPath();
      for (let y = 0; y <= n; y += n / 16) {
        const px = x + Math.sin((y / n) * 6.283 + ph) * sway;   // nilai pada y=0 dan y=n sama, jadi menyambung
        if (y === 0) g.moveTo(px, y); else g.lineTo(px, y);
      }
      g.stroke();
    }
  };
}
// goresan halus satu arah untuk logam
function brushed(seed) {
  return (g, n) => {
    const r = mulberry(seed);
    g.fillStyle = 'rgb(170,170,170)';
    g.fillRect(0, 0, n, n);
    for (let i = 0; i < 700; i++) {
      const v = 110 + r() * 130;
      g.strokeStyle = `rgba(${v},${v},${v},0.3)`;
      g.lineWidth = 0.5 + r();
      const y = r() * n;
      g.beginPath(); g.moveTo(0, y); g.lineTo(n, y); g.stroke();
    }
  };
}

// Stiker lantai: tulisan terbaca dari utara. UV model memakai satuan meter, satu ulangan = 0,3 m x 0,05 m.
function tapeTexture() {
  const c = document.createElement('canvas');
  c.width = 600; c.height = 100;
  const g = c.getContext('2d');
  g.fillStyle = '#f2c200';
  g.fillRect(0, 0, c.width, c.height);
  g.fillStyle = '#141414';
  g.fillRect(0, 0, c.width, 7);
  g.fillRect(0, c.height - 7, c.width, 7);
  g.font = '800 62px Arial, sans-serif';
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.fillText('DO NOT ENTER', c.width / 2, c.height / 2 + 3);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(-1 / 0.3, 1 / 0.05);
  t.offset.set(0, 0.5);
  t.anisotropy = 8;
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function enhanceMaterials(root) {
  const fineBump = canvasTexture(256, speckle(90, 165, 11), 7, 7);       // cat serbuk pada rak dan panel
  const plaster = canvasTexture(512, speckle(100, 155, 21), 3, 3);       // cat dinding
  const wallTint = canvasTexture(512, mottle(250, 9, 31, 26), 0.45, 0.45, true);
  const floorRough = canvasTexture(512, mottle(165, 75, 41, 34), 0.5, 0.5);
  const floorTint = canvasTexture(512, mottle(252, 7, 43, 28), 0.3, 0.3, true);
  const woodDark = canvasTexture(1024, woodGrain(51), 1.1, 0.8, true);
  const woodPale = canvasTexture(1024, woodGrain(52, 0.14), 1.4, 0.8, true);
  const metal = canvasTexture(256, brushed(61), 1, 8);
  const seen = new Set();
  eachMesh(root, (m) => {
    const mat = m.material;
    if (seen.has(mat)) return;
    seen.add(mat);
    const n = mat.name.replace('mat_', '');
    const bump = (tex, s) => { mat.bumpMap = tex; mat.bumpScale = s; };
    if (n === 'wall') { mat.map = wallTint; bump(plaster, 0.35); }
    if (n === 'skirting') mat.envMapIntensity = 0.6;
    if (n === 'floor_epoxy') { mat.map = floorTint; mat.roughnessMap = floorRough; mat.roughness = 0.42; mat.envMapIntensity = 1.5; }
    if (['rack_white', 'rack_cover', 'panel_grey', 'door_sage', 'box_grey'].includes(n)) bump(fineBump, 0.25);
    if (n === 'desk_brown') { mat.map = woodDark; mat.roughness = 0.42; }
    if (n === 'door_brown') mat.map = woodDark;
    if (n === 'door_grey') { mat.map = woodPale; }
    if (n === 'steel') { mat.roughnessMap = metal; mat.roughness = 0.75; mat.envMapIntensity = 2.0; }
    if (n === 'black_plastic' || n === 'bin_brown' || n === 'lid_yellow') bump(fineBump, 0.15);
    if (n === 'ppe_white' || n === 'ppe_blue') { bump(fineBump, 0.4); mat.side = THREE.DoubleSide; }
    if (n === 'mat_blue' || n === 'mat_blue_rim') bump(fineBump, 0.9);
    if (n === 'floor_tape') { mat.map = tapeTexture(); mat.color.set(0xffffff); }
    if (n === 'screen') mat.envMapIntensity = 1.6;
    if (n === 'tl_diffuser') { mat.emissive.set(0xfffdf4); mat.emissiveIntensity = 1.6; mat.toneMapped = false; }
    if (n === 'glass') {
      mat.transparent = true;
      mat.opacity = 0.16;
      mat.roughness = 0.04;
      mat.metalness = 0;
      mat.depthWrite = false;
      mat.envMapIntensity = 2.2;
    }
    mat.needsUpdate = true;
  });
}

// Tampilan layar sistem kontrol. Hanya gambaran antarmuka, tanpa angka, sampai disambungkan ke data asli.
function setupHmiDisplay(mesh) {
  const pos = mesh.geometry.attributes.position, box = new THREE.Box3().setFromBufferAttribute(pos);
  const facesWest = (box.max.z - box.min.z) > (box.max.x - box.min.x);
  const uv = new Float32Array(pos.count * 2);
  for (let i = 0; i < pos.count; i++) {
    uv[i * 2] = facesWest ? (pos.getZ(i) - box.min.z) / (box.max.z - box.min.z) : (pos.getX(i) - box.min.x) / (box.max.x - box.min.x);
    uv[i * 2 + 1] = (pos.getY(i) - box.min.y) / (box.max.y - box.min.y);
  }
  mesh.geometry.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  const c = document.createElement('canvas');
  c.width = 512; c.height = 340;
  const g = c.getContext('2d');
  g.fillStyle = '#0e1d28'; g.fillRect(0, 0, 512, 340);
  g.fillStyle = '#17394a'; g.fillRect(0, 0, 512, 42);
  g.fillStyle = '#3fbf7f'; g.fillRect(14, 14, 90, 14);
  [[14, 58, 150, 118], [180, 58, 150, 118], [346, 58, 152, 118], [14, 192, 318, 134]].forEach(([x, y, w, h]) => {
    g.fillStyle = '#1a2f3d'; g.fillRect(x, y, w, h);
  });
  ['#4fc3f7', '#3fbf7f', '#e0b84a'].forEach((col, i) => {
    g.fillStyle = col; g.fillRect(28 + i * 166, 78, 80, 10);
    g.fillStyle = '#2c4a5c'; g.fillRect(28 + i * 166, 104, 118, 8); g.fillRect(28 + i * 166, 124, 90, 8);
  });
  g.strokeStyle = '#4fc3f7'; g.lineWidth = 3; g.beginPath();
  for (let i = 0; i <= 28; i++) { const x = 26 + i * 10.5, y = 262 + Math.sin(i * 0.62) * 26 + Math.sin(i * 0.19) * 18; i ? g.lineTo(x, y) : g.moveTo(x, y); }
  g.stroke();
  for (let i = 0; i < 4; i++) { g.fillStyle = i === 2 ? '#c9504a' : '#3fbf7f'; g.fillRect(346, 192 + i * 35, 152, 28); }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  mesh.material = new THREE.MeshStandardMaterial({ name: 'mat_hmi_screen', map: tex, emissiveMap: tex, emissive: 0xffffff, emissiveIntensity: 0.85, roughness: 0.25 });
}

// Selada: daun tipis melengkung dengan tepi bergelombang, warna pangkal lebih pucat dari ujung.
function leaf(len, wid, lift, droop, angle, seed) {
  const r = mulberry(seed);
  const rows = 4, cols = 2, pos = [], col = [], idx = [];
  const ruffle = 0.14 + r() * 0.12;
  for (let i = 0; i <= rows; i++) {
    const t = i / rows;
    const half = wid * Math.sin(Math.PI * Math.pow(t, 0.72)) * (1 + 0.1 * Math.sin(t * 9 + seed));
    for (let j = 0; j <= cols; j++) {
      const s = j / cols * 2 - 1;
      const x = len * t;
      const edge = Math.abs(s);
      const y = lift * Math.sin(t * Math.PI * 0.55) - droop * t * t + edge * half * ruffle * Math.sin(t * 13 + s * 3 + seed) + edge * half * 0.35;
      pos.push(x, y, s * half);
      const shade = 1.2 - 0.42 * t - 0.1 * edge;
      col.push(shade, shade, shade * 0.86);
    }
  }
  for (let i = 0; i < rows; i++) for (let j = 0; j < cols; j++) {
    const a = i * (cols + 1) + j, b = a + 1, c = a + cols + 1, d = c + 1;
    idx.push(a, c, b, b, c, d);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  g.setIndex(idx);
  g.rotateY(angle);
  return g;
}
function plantGeometry() {
  const leaves = [];
  const add = (n, len, wid, lift, droop, a0, seedBase) => {
    for (let i = 0; i < n; i++) leaves.push(leaf(len, wid, lift, droop, a0 + (i / n) * Math.PI * 2, seedBase + i));
  };
  add(6, 0.07, 0.027, 0.03, 0.012, 0, 1);       // daun luar
  add(4, 0.052, 0.022, 0.044, 0.004, 0.5, 11);  // daun tengah
  add(2, 0.03, 0.015, 0.05, 0, 1.1, 21);        // daun muda
  const g = mergeGeometries(leaves);
  g.computeVertexNormals();
  return g;
}

// ------------------------------------------------------------------ mesin
export async function createPlantFactoryScene(options = {}) {
  const { container, assetsUrl = DEFAULT_ASSETS, provider: providerOption, holeStates = HOLE_STATES, quality = 'auto', tooltip = true } = options;
  if (!(container instanceof HTMLElement)) throw new Error('createPlantFactoryScene: container harus elemen HTML');
  if (getComputedStyle(container).position === 'static') container.style.position = 'relative';

  const base = new URL(String(assetsUrl).replace(/\/?$/, '/'), location.href);
  const modelUrl = options.modelUrl || new URL('plant_factory.glb', base).href;
  const manifestUrl = options.manifestUrl || new URL('manifest.json', base).href;

  const listeners = new Map();
  const emit = (type, payload) => { for (const fn of listeners.get(type) || []) fn(payload); };
  const dom = new AbortController();

  const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.NeutralToneMapping;
    container.prepend(renderer.domElement);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0xe7eae7);
  const camera = new THREE.PerspectiveCamera(38, 1, 0.05, 80);
  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.08;
  controls.maxPolarAngle = Math.PI * 0.62;
  controls.minDistance = 0.4;
  controls.maxDistance = 25;
  RectAreaLightUniformsLib.init();

  // ------------------------------------------------------------------ cahaya
  // Pantulan lingkungan untuk lantai epoxy, logam, dan kaca.
  const pmrem = new THREE.PMREMGenerator(renderer);
  scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  scene.environmentIntensity = 0.42;

  const hemi = new THREE.HemisphereLight(0xffffff, 0xe4e6e3, 1.7);
  scene.add(hemi);
  // cahaya plafon: dari hampir tepat di atas dengan bayangan lembut, bukan matahari miring
  const sun = new THREE.DirectionalLight(0xffffff, 0.85);
  sun.position.set(4.6, 12, 0.6);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  Object.assign(sun.shadow.camera, { left: -8, right: 8, top: 8, bottom: -8, near: 1, far: 30 });
  sun.shadow.bias = -0.0004;
  sun.shadow.normalBias = 0.012;
  sun.shadow.radius = 7;
  sun.shadow.blurSamples = 16;
  scene.add(sun);
  scene.add(sun.target);

  // lantai luar bangunan: hanya menerima bayangan
  const yard = new THREE.Mesh(new THREE.PlaneGeometry(60, 60), new THREE.ShadowMaterial({ opacity: 0.13 }));
  yard.rotation.x = -Math.PI / 2;
  yard.position.y = -0.1;
  yard.receiveShadow = true;
  scene.add(yard);

  // ------------------------------------------------------------------ pasca-proses
  // Oklusi ambien membuat sudut dan pertemuan benda tampak menyatu dengan ruang.
  const composer = new EffectComposer(renderer, new THREE.WebGLRenderTarget(1, 1, { type: THREE.HalfFloatType, samples: 4 }));
  composer.addPass(new RenderPass(scene, camera));
  const gtao = new GTAOPass(scene, camera, 1, 1);
  gtao.blendIntensity = 0.9;
  gtao.updateGtaoMaterial({ radius: 0.32, distanceExponent: 1.2, thickness: 1, scale: 1.25, samples: 16, distanceFallOff: 1, screenSpaceRadius: false });
  gtao.updatePdMaterial({ lumaPhi: 10, depthPhi: 2, normalPhi: 3, radius: 5, radiusExponent: 1, rings: 2, samples: 16 });
  // benda tembus pandang tidak boleh menghasilkan bayangan oklusi
  const baseOverride = gtao.overrideVisibility.bind(gtao);
  gtao.overrideVisibility = function () {
    baseOverride();
    this.scene.traverse((o) => { if (o.isMesh && (o.material.transparent || o.material.isShadowMaterial)) o.visible = false; });
  };
  composer.addPass(gtao);
  composer.addPass(new OutputPass());

  renderer.domElement.style.cssText += ';position:absolute;inset:0;width:100%;height:100%;display:block';

  let highQuality = quality === 'auto' ? innerWidth >= 980 : !!quality;
  let qualityTouched = quality !== 'auto';
  gtao.enabled = highQuality;

  let realLight = false;
  let showCeiling = false;
  let lowWalls = true;
  let showCovers = true;
  const LOW_WALL_Y = 0.45;
  const WALL_NODES = ['wall_north', 'wall_south', 'wall_east', 'wall_west', 'partition', 'door_grow', 'door_control', 'door_glass_north', 'door_waste', 'waste_room', 'waste_pipes', 'wall_fittings', 'window_frame', 'window_glass'];
  const WALL_ATTACHED = ['ac_control', 'ac_grow_north', 'ac_grow_south', 'tv_wall', 'wall_services_south', 'wall_services_west'];
  const nodes = new Map();          // nama node -> Object3D
  const lampLights = new Map();     // id lampu -> RectAreaLight
  const lampMats = new Map();       // id lampu -> material
  const pumpMats = new Map();       // id pompa -> material
  const pickableObjects = [];       // objek ERP selain lubang
  const cutaways = [];              // {obj, side}
  const wallMeshes = [];            // {mesh, full, low}

  let ringMesh, plantMesh, potMesh;
  let filter = { rack: 0, tier: 0 };
  let selected = null;              // {kind:'hole', id} | {kind:'object', id}
  let hovered = -1;
  let currentView = 'iso';

  const getOptions = () => ({ realLight, showCeiling, lowWalls, showCovers, highQuality });

  // ---------------------------------------------------------------- muat model
  const [gltf, manifest] = await Promise.all([
    new GLTFLoader().loadAsync(modelUrl),
    fetch(manifestUrl).then((r) => { if (!r.ok) throw new Error('manifest ' + r.status); return r.json(); }),
  ]);
  const holes = manifest.holes;
  const holeIndex = new Map(holes.map((h, i) => [h.id, i]));
  const objectIds = new Set(manifest.objects.map((o) => o.id));
  const provider = typeof providerOption === 'function' ? providerOption(manifest) : (providerOption || new SimulatedProvider(manifest));
  if (typeof provider.getHole !== 'function' || typeof provider.lamps?.get !== 'function' || typeof provider.pumps?.get !== 'function') {
    throw new Error('Provider harus memiliki getHole(id), lamps.get(id), dan pumps.get(id)');
  }

  scene.add(gltf.scene);
  sun.target.position.set(manifest.bounds.xMax / 2, 0, manifest.bounds.zNorth / 2);

  gltf.scene.traverse((o) => {
    if (o.userData?.type || o.name) nodes.set(o.name, o);
    if (o.userData?.cutaway) cutaways.push({ obj: o, side: o.userData.cutaway });
  });
  eachMesh(gltf.scene, (m) => {
    m.castShadow = true;
    m.receiveShadow = true;
    const n = m.material.name;
    if (n === 'mat_glass') m.castShadow = false;
    if (n === 'mat_led' || n === 'mat_tl_diffuser') m.castShadow = false;
    if (n === 'mat_hmi_display') setupHmiDisplay(m);
  });
  enhanceMaterials(gltf.scene);
  for (const name of ['ceiling', 'ceiling_lights_grow']) eachMesh(nodes.get(name), (m) => { m.castShadow = false; });

  // versi dinding rendah: titik di atas batas ditekan ke batas, sehingga dinding tampak utuh dengan tutup atas
  for (const name of WALL_NODES) eachMesh(nodes.get(name), (mesh) => {
    const full = mesh.geometry, low = full.clone(), pos = low.attributes.position;
    for (let i = 0; i < pos.count; i++) if (pos.getY(i) > LOW_WALL_Y) pos.setY(i, LOW_WALL_Y);
    low.computeBoundingSphere();
    low.computeBoundingBox();
    wallMeshes.push({ mesh, full, low });
  });

  function setupObjects() {
    for (const o of manifest.objects) {
      const node = nodes.get(o.node);
      if (!node) throw new Error('Node hilang di GLB: ' + o.node);
      node.userData.objectId = o.id;
      if (o.type === 'lamp') {
        const mat = new THREE.MeshStandardMaterial({ color: 0xffe3f6, emissive: LED_COLOR, emissiveIntensity: 2 });
        eachMesh(node, (m) => { if (m.material.name === 'mat_led') m.material = mat; });
        lampMats.set(o.id, mat);
        const light = new THREE.RectAreaLight(LED_COLOR, 0, 0.66, 3.9);
        light.position.set(o.pos[0], o.pos[1] - 0.005, o.pos[2]);
        light.lookAt(o.pos[0], 0, o.pos[2]);
        scene.add(light);
        lampLights.set(o.id, light);
      }
      if (o.type === 'pump') {
        const mat = new THREE.MeshStandardMaterial({ color: 0x9a9c9b, roughness: 0.5, emissive: 0x000000 });
        eachMesh(node, (m) => { if (m.material.name === 'mat_panel_grey') m.material = mat; });
        pumpMats.set(o.id, mat);
        // pompa di dalam kontainer tidak terlihat, jadi kontainer yang menjadi area klik
        if (o.host) {
          const host = nodes.get(o.host);
          if (!host) throw new Error('Node hilang di GLB: ' + o.host);
          host.userData.objectId = o.id;
          pickableObjects.push(host);
        }
      }
      pickableObjects.push(node);
    }
  }

  function setupHoles() {
    const ring = new THREE.RingGeometry(0.0255, 0.0335, 24);
    ring.rotateX(-Math.PI / 2);
    ringMesh = new THREE.InstancedMesh(ring, new THREE.MeshBasicMaterial({ toneMapped: false }), holes.length);
    plantMesh = new THREE.InstancedMesh(plantGeometry(), new THREE.MeshStandardMaterial({ roughness: 0.62, vertexColors: true, side: THREE.DoubleSide }), holes.length);
    // pot jaring hitam di dalam lubang
    const pot = new THREE.LatheGeometry([[0.0, -0.001], [0.02, -0.001], [0.0235, 0.003], [0.0255, 0.003], [0.0255, 0.0015]].map(([x, y]) => new THREE.Vector2(x, y)), 14);
    potMesh = new THREE.InstancedMesh(pot, new THREE.MeshStandardMaterial({ color: 0x1b1d1c, roughness: 0.6 }), holes.length);
    const big = new THREE.Sphere(new THREE.Vector3(manifest.bounds.xMax / 2, 1, manifest.bounds.zNorth / 2), 12);
    ringMesh.boundingSphere = big; plantMesh.boundingSphere = big; potMesh.boundingSphere = big;
    ringMesh.frustumCulled = plantMesh.frustumCulled = potMesh.frustumCulled = false;
    plantMesh.castShadow = true;
    plantMesh.receiveShadow = true;
    scene.add(ringMesh, plantMesh, potMesh);
    holes.forEach((_, i) => refreshHole(i));
  }

  const _m = new THREE.Matrix4();
  const _p = new THREE.Vector3();
  const _q = new THREE.Quaternion();
  const _s = new THREE.Vector3();
  const _c = new THREE.Color();
  const _yAxis = new THREE.Vector3(0, 1, 0);

  const holeVisible = (h) => (!filter.rack || h.rack === filter.rack) && (!filter.tier || h.tier === filter.tier);

  function refreshHole(i) {
    const h = holes[i];
    const data = provider.getHole(h.id) || { state: 'kosong' };
    const st = holeStates[data.state] || holeStates.kosong;
    const vis = holeVisible(h);
    const isSel = selected?.kind === 'hole' && selected.id === h.id;
    const isHover = hovered === i;

    _p.set(h.pos[0], h.pos[1] + 0.0035, h.pos[2]);
    _s.setScalar(vis ? (isSel ? 1.55 : isHover ? 1.3 : 1) : 0);
    ringMesh.setMatrixAt(i, _m.compose(_p, _q.identity(), _s));
    _c.setHex(isSel ? 0x12a5ff : st.color);
    ringMesh.setColorAt(i, _c);
    _s.setScalar(vis ? 1 : 0);
    potMesh.setMatrixAt(i, _m.compose(_p, _q, _s));

    // variasi kecil per lubang supaya tanaman tidak tampak identik
    const v = 0.9 + ((i * 2654435761) >>> 0) / 4294967296 * 0.25;
    _p.set(h.pos[0], h.pos[1], h.pos[2]);
    _q.setFromAxisAngle(_yAxis, i * 2.399);
    _s.setScalar(vis ? st.plant * v * 1.3 : 0);
    plantMesh.setMatrixAt(i, _m.compose(_p, _q, _s));
    _c.setHex(data.state === 'masalah' ? 0xb09a45 : data.state === 'semai' ? 0x8fcf63 : 0x58ad4a);
    _c.offsetHSL(((i * 40503) % 97) / 97 * 0.03 - 0.015, 0, ((i * 2971) % 89) / 89 * 0.05 - 0.025);
    plantMesh.setColorAt(i, _c);

    ringMesh.instanceMatrix.needsUpdate = plantMesh.instanceMatrix.needsUpdate = potMesh.instanceMatrix.needsUpdate = true;
    ringMesh.instanceColor.needsUpdate = plantMesh.instanceColor.needsUpdate = true;
  }
  const refreshAllHoles = () => holes.forEach((_, i) => refreshHole(i));

  // ---------------------------------------------------------------- status lampu + pompa
  function applyLighting() {
    hemi.intensity = realLight ? 1.15 : 1.7;
    hemi.color.set(realLight ? 0xf08be0 : 0xffffff);
    hemi.groundColor.set(realLight ? 0xe58ad8 : 0xe4e6e3);
    sun.intensity = realLight ? 0 : 0.85;
    scene.environmentIntensity = realLight ? 0.16 : 0.42;
    yard.visible = !realLight;
    scene.background.set(realLight ? 0x1b1119 : 0xe7eae7);
    for (const [id, mat] of lampMats) {
      const on = !!provider.lamps.get(id);
      mat.emissiveIntensity = on ? (realLight ? 4 : 2) : 0;
      mat.color.set(on ? 0xffe3f6 : 0xbfc2c0);
      lampLights.get(id).intensity = on ? (realLight ? 7 : 1.1) : 0;
    }
    for (const [id, mat] of pumpMats) mat.emissive.set(provider.pumps.get(id) ? 0x1c8c43 : 0x8c1c1c);
    gtao.enabled = highQuality;
    for (const w of wallMeshes) w.mesh.geometry = lowWalls ? w.low : w.full;
  }

  // ---------------------------------------------------------------- filter rak + tingkat
  function applyFilter() {
    for (const [name, o] of nodes) {
      const u = o.userData;
      if (!u || u.rack == null) continue;
      const rackOk = !filter.rack || u.rack === filter.rack;
      // tabung LED menutup lubang dari atas, jadi disembunyikan saat memilih satu tingkat
      if (u.type === 'lamp') o.visible = rackOk && !filter.tier;
      else if (u.tier != null) o.visible = rackOk && (!filter.tier || u.tier === filter.tier);
      else if (u.type === 'rack_top') o.visible = rackOk && !filter.tier && showCovers;   // penutup atas menghalangi lubang
      else if (name.includes('structure')) o.visible = true;   // rangka tetap terlihat agar orientasi tidak hilang
    }
    refreshAllHoles();
  }

  // ---------------------------------------------------------------- kamera
  function viewPresets() {
    const b = manifest.bounds;
    const cx = b.xMax / 2, cz = b.zNorth / 2;
    return {
      iso: { pos: [cx - 5.6, 7.2, 6.4], tgt: [cx - 0.1, 0.5, cz] },
      top: { pos: [cx, 11.5, cz + 0.01], tgt: [cx, 0, cz] },
      grow: { pos: [b.growX0 + 0.2, 2.45, b.zNorth + 0.65], tgt: [b.growX0 + 2.0, 0.85, -2.1], fov: 68 },
      control: { pos: [b.controlX / 2 + 0.3, 2.55, -0.2], tgt: [b.controlX / 2 - 0.1, 0.55, -3.3], fov: 72 },
    };
  }
  function setView(name) {
    const v = viewPresets()[name];
    camera.fov = v.fov || 38;
    camera.updateProjectionMatrix();
    camera.position.set(...v.pos);
    controls.target.set(...v.tgt);
    // tampilan luar dimundurkan pada layar sempit agar seluruh bangunan tetap masuk
    const minAspect = { iso: 1.35, top: 1.05 }[name];
    if (minAspect && camera.aspect < minAspect) {
      camera.position.sub(controls.target).multiplyScalar(minAspect / camera.aspect).add(controls.target);
    }
    controls.update();
    // tampilan luar memakai dinding rendah, tampilan dalam memakai dinding penuh
    lowWalls = name === 'iso' || name === 'top';
    showCeiling = !lowWalls;
    applyLighting();
    currentView = name;
    emit('view', name);
    emit('options', getOptions());
  }

  // Dinding di sisi kamera disembunyikan agar isi ruangan selalu terlihat.
  function updateCutaway() {
    const b = manifest.bounds, p = camera.position;
    const hide = {
      north: p.z < b.zNorth, south: p.z > b.zSouth, west: p.x < b.xMin, east: p.x > b.xMax,
      ceiling: !showCeiling,
    };
    // pada mode dinding rendah semua dinding tetap tampil supaya batas ruangan terbaca
    for (const c of cutaways) c.obj.visible = (lowWalls && c.side !== 'ceiling') || !hide[c.side];
    if (lowWalls) for (const n of WALL_ATTACHED) nodes.get(n).visible = false;
  }

  // ---------------------------------------------------------------- memilih objek
  const ray = new THREE.Raycaster();
  const ndc = new THREE.Vector2();

  function pick(ev) {
    const r = renderer.domElement.getBoundingClientRect();
    ndc.set(((ev.clientX - r.left) / r.width) * 2 - 1, -((ev.clientY - r.top) / r.height) * 2 + 1);
    ray.setFromCamera(ndc, camera);
    const hits = ray.intersectObjects([ringMesh, plantMesh, ...pickableObjects.filter((o) => o.visible)], true);
    // penutup rak menghalangi semua yang ada di bawahnya
    const covers = [...nodes.values()].filter((o) => o.userData?.type === 'rack_top' && o.visible);
    const coverHit = ray.intersectObjects(covers, true)[0];
    for (const hit of hits) {
      if (coverHit && hit.distance > coverHit.distance) break;
      if (hit.object === ringMesh || hit.object === plantMesh) {
        if (holeVisible(holes[hit.instanceId])) return { kind: 'hole', index: hit.instanceId, id: holes[hit.instanceId].id };
        continue;
      }
      let o = hit.object;
      while (o && !o.userData.objectId) o = o.parent;
      if (o && isVisibleChain(o)) return { kind: 'object', id: o.userData.objectId };
    }
    return null;
  }
  function isVisibleChain(o) { for (; o; o = o.parent) if (!o.visible) return false; return true; }

  const tip = document.createElement('div');
  tip.style.cssText = 'position:absolute;display:none;background:rgba(20,26,24,.92);color:#fff;padding:3px 7px;border-radius:4px;font:12px system-ui,sans-serif;pointer-events:none;transform:translate(12px,12px);white-space:nowrap;z-index:5';
  if (tooltip) container.append(tip);

  function onMove(ev) {
    const p = pick(ev);
    const next = p?.kind === 'hole' ? p.index : -1;
    if (next !== hovered) {
      const prev = hovered;
      hovered = next;
      if (prev >= 0) refreshHole(prev);
      if (next >= 0) refreshHole(next);
    }
    renderer.domElement.style.cursor = p ? 'pointer' : 'grab';
    if (p) {
      const r = container.getBoundingClientRect();
      tip.style.display = 'block';
      tip.style.left = ev.clientX - r.left + 'px';
      tip.style.top = ev.clientY - r.top + 'px';
      tip.textContent = p.id;
    } else tip.style.display = 'none';
    emit('hover', p ? { kind: p.kind, id: p.id } : null);
  }

  let downAt = null;
  const signal = dom.signal;
  renderer.domElement.addEventListener('pointerdown', (e) => { downAt = [e.clientX, e.clientY]; }, { signal });
  renderer.domElement.addEventListener('pointerup', (e) => {
    if (!downAt || Math.hypot(e.clientX - downAt[0], e.clientY - downAt[1]) > 5) return;
    const p = pick(e);
    select(p ? { kind: p.kind, id: p.id } : null);
  }, { signal });
  renderer.domElement.addEventListener('pointermove', onMove, { signal });
  renderer.domElement.addEventListener('pointerleave', () => { tip.style.display = 'none'; }, { signal });

  function select(sel) {
    if (sel && !(sel.kind === 'hole' ? holeIndex.has(sel.id) : sel.kind === 'object' && objectIds.has(sel.id))) return false;
    const prev = selected;
    selected = sel ? { kind: sel.kind, id: sel.id } : null;
    if (prev?.kind === 'hole') refreshHole(holeIndex.get(prev.id));
    if (selected?.kind === 'hole') refreshHole(holeIndex.get(selected.id));
    emit('select', selected);
    return true;
  }

  function setFilter(next) {
    filter = { rack: next.rack ?? filter.rack, tier: next.tier ?? filter.tier };
    applyFilter();
    emit('filter', { ...filter });
  }

  function focusHole(id) {
    const i = holeIndex.get(id);
    if (i === undefined) return false;
    setFilter({ rack: 0, tier: holes[i].tier });   // penutup dan lampu rak disembunyikan agar lubang terlihat
    return select({ kind: 'hole', id });
  }

  function setOptions(next) {
    if ('realLight' in next) realLight = !!next.realLight;
    if ('showCeiling' in next) showCeiling = !!next.showCeiling;
    if ('lowWalls' in next) lowWalls = !!next.lowWalls;
    if ('highQuality' in next) { highQuality = !!next.highQuality; qualityTouched = true; }
    if ('showCovers' in next) { showCovers = !!next.showCovers; applyFilter(); }
    applyLighting();
    emit('options', getOptions());
  }

  // ---------------------------------------------------------------- loop
  function resize() {
    const w = container.clientWidth, h = container.clientHeight;
    if (!w || !h) return;
    renderer.setSize(w, h, false);
    composer.setPixelRatio(renderer.getPixelRatio());
    composer.setSize(w, h);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  const resizeObserver = new ResizeObserver(resize);
  resizeObserver.observe(container);

  // Bila perangkat terlalu berat, kualitas tinggi dimatikan sekali secara otomatis.
  const perf = { last: 0, sum: 0, n: 0, avgMs: 0 };
  function watchPerformance(now) {
    const dt = now - perf.last;
    perf.last = now;
    if (dt <= 0 || dt > 500) return;
    perf.sum += dt;
    if (++perf.n < 90) return;
    perf.avgMs = perf.sum / perf.n;
    perf.sum = perf.n = 0;
    if (highQuality && !qualityTouched && perf.avgMs > 55) {
      highQuality = false;
      applyLighting();
      emit('options', getOptions());
    }
  }

  function tick(now) {
    watchPerformance(now);
    controls.update();
    updateCutaway();
    composer.render();
  }

  setupObjects();
  setupHoles();
  resize();
  setView('iso');
  applyFilter();
  applyLighting();
  resize();
  renderer.setAnimationLoop(tick);

  let disposed = false;
  function dispose() {
    if (disposed) return;
    disposed = true;
    renderer.setAnimationLoop(null);
    dom.abort();
    resizeObserver.disconnect();
    controls.dispose();
    const seen = new Set();
    const free = (x) => { if (x && !seen.has(x)) { seen.add(x); x.dispose?.(); } };
    scene.traverse((o) => {
      free(o.geometry);
      for (const m of [].concat(o.material || [])) {
        free(m);
        for (const v of Object.values(m)) if (v?.isTexture) free(v);
      }
    });
    for (const w of wallMeshes) { free(w.full); free(w.low); }
    scene.environment?.dispose();
    pmrem.dispose();
    composer.dispose();
    gtao.dispose();
    renderer.dispose();
    renderer.domElement.remove();
    tip.remove();
    listeners.clear();
  }

  return {
    manifest,
    provider,
    holeStates,
    get selected() { return selected; },
    get filter() { return { ...filter }; },
    get view() { return currentView; },
    get options() { return getOptions(); },
    setView,
    setFilter,
    setOptions,
    select,
    focusHole,
    refreshHole(id) { const i = holeIndex.get(id); if (i === undefined) return false; refreshHole(i); return true; },
    refresh() { refreshAllHoles(); applyLighting(); },
    on(type, fn) {
      if (!listeners.has(type)) listeners.set(type, new Set());
      listeners.get(type).add(fn);
      return () => listeners.get(type)?.delete(fn);
    },
    dispose,
    three: { THREE, scene, camera, renderer, controls, composer, gtao, nodes, perf },
  };
}
