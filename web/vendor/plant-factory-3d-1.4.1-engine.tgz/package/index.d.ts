import type * as THREE from 'three';

export type HoleStateKey = 'kosong' | 'semai' | 'vegetatif' | 'siap_panen' | 'masalah' | (string & {});
export interface HoleStateStyle { label: string; color: number; plant: number; }
export const HOLE_STATES: Record<string, HoleStateStyle>;

export interface HoleRecord { id: string; rack: number; tier: number; gully: number; hole: number; pos: [number, number, number]; }
export interface ObjectRecord {
  id: string;
  node: string;
  type: 'lamp' | 'pump' | 'sensor_climate' | 'sensor_nutrient' | 'tank' | 'cctv' | (string & {});
  pos: [number, number, number];
  rack?: number;
  tier?: number;
  /** Posisi atau keberadaannya masih asumsi, belum dikonfirmasi. */
  assumed?: boolean;
  /** Node yang menjadi area klik, bila objeknya tertutup (pompa di dalam kontainer). */
  host?: string;
}
export interface Manifest {
  schema_version: number;
  units: 'meter';
  coords: string;
  id_convention: string;
  bounds: { xMin: number; xMax: number; zNorth: number; zSouth: number; height: number; controlX: number; growX0: number };
  rack: { count: number; tiers: number; gullies_per_tier: number; holes_per_gully: number };
  holes: HoleRecord[];
  objects: ObjectRecord[];
}

/** Bacaan harus sinkron. Ambil data ERP di luar mesin, simpan di cache, lalu panggil scene.refresh(). */
export interface PlantFactoryProvider {
  getHole(id: string): { state: HoleStateKey; [k: string]: unknown } | undefined;
  lamps: { get(id: string): boolean | undefined };
  pumps: { get(id: string): boolean | undefined };
}

export type ViewName = 'iso' | 'top' | 'grow' | 'control';
export type Selection = { kind: 'hole' | 'object'; id: string };
export interface SceneOptionsState { realLight: boolean; showCeiling: boolean; lowWalls: boolean; showCovers: boolean; highQuality: boolean; }
export interface SceneEvents {
  select: Selection | null;
  hover: Selection | null;
  view: ViewName;
  filter: { rack: number; tier: number };
  options: SceneOptionsState;
}

export interface CreateOptions<P extends PlantFactoryProvider = PlantFactoryProvider> {
  /** Elemen pembungkus. Harus punya tinggi; kanvas mengisi seluruh elemen. */
  container: HTMLElement;
  /** URL folder berisi plant_factory.glb dan manifest.json. */
  assetsUrl?: string | URL;
  modelUrl?: string;
  manifestUrl?: string;
  /** Bawaan: SimulatedProvider, yaitu data contoh. */
  provider?: P | ((manifest: Manifest) => P);
  holeStates?: Record<string, HoleStateStyle>;
  /** 'auto' mengaktifkan oklusi ambien pada layar lebar dan mematikannya bila perangkat berat. */
  quality?: 'auto' | boolean;
  tooltip?: boolean;
}

export interface PlantFactoryScene<P extends PlantFactoryProvider = PlantFactoryProvider> {
  readonly manifest: Manifest;
  readonly provider: P;
  readonly holeStates: Record<string, HoleStateStyle>;
  readonly selected: Selection | null;
  readonly filter: { rack: number; tier: number };
  readonly view: ViewName;
  readonly options: SceneOptionsState;
  setView(name: ViewName): void;
  /** 0 berarti semua. */
  setFilter(filter: { rack?: number; tier?: number }): void;
  setOptions(options: Partial<SceneOptionsState>): void;
  /** false bila ID tidak dikenal. */
  select(selection: Selection | null): boolean;
  /** Tampilkan tingkat lubang lalu pilih lubangnya. false bila ID tidak dikenal. */
  focusHole(id: string): boolean;
  refreshHole(id: string): boolean;
  /** Baca ulang semua lubang, lampu, dan pompa dari provider. */
  refresh(): void;
  on<K extends keyof SceneEvents>(type: K, fn: (payload: SceneEvents[K]) => void): () => void;
  dispose(): void;
  three: {
    THREE: typeof THREE;
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    renderer: THREE.WebGLRenderer;
    controls: unknown;
    composer: unknown;
    gtao: unknown;
    nodes: Map<string, THREE.Object3D>;
    perf: { avgMs: number };
  };
}

export function createPlantFactoryScene<P extends PlantFactoryProvider = PlantFactoryProvider>(options: CreateOptions<P>): Promise<PlantFactoryScene<P>>;

export class SimulatedProvider implements PlantFactoryProvider {
  constructor(manifest: Manifest);
  holes: Map<string, { state: HoleStateKey; crop: string; plantedOn: string; note: string }>;
  lamps: Map<string, boolean>;
  pumps: Map<string, boolean>;
  getHole(id: string): { state: HoleStateKey; crop: string; plantedOn: string; note: string } | undefined;
  updateHole(id: string, patch: Record<string, unknown>): void;
  setLamp(id: string, on: boolean): void;
  setPump(id: string, on: boolean): void;
  readings(t?: number): Record<'climate' | 'nutrient', Record<string, { label: string; value: number; unit: string; d: number }>>;
}

// ------------------------------------------------------------------ growth chamber FPG450

export type SeedStateKey = 'kosong' | 'disemai' | 'berkecambah' | 'siap_pindah' | 'masalah' | (string & {});
export interface SeedStateStyle {
  label: string;
  color: number;
  plant: number;
  plugs: boolean;
  /** Nampan ditutup nampan lain yang dibalik. */
  lid?: boolean;
}
export const SEED_STATES: Record<string, SeedStateStyle>;
/** Warna nampan pada foto: hijau, merah, biru, ungu. */
export const TRAY_COLORS: Record<string, number>;

export interface SeedSlotRecord { id: string; shelf: number; position: number; row: number; column: number; pos: [number, number, number]; }
export interface SeedShelfRecord { shelf: number; level: number; y: number; lamp: string; }
export interface ChamberObjectRecord {
  id: string;
  node: string;
  type: 'chamber' | 'lamp' | 'sensor_climate' | (string & {});
  pos: [number, number, number];
  level?: number;
  /** Rak yang diterangi papan ini. */
  lights_shelf?: number | null;
  assumed?: boolean;
  /** Node lain yang juga memilih objek ini saat diklik. */
  hosts?: string[];
}
export interface ChamberManifest {
  schema_version: number;
  units: 'meter';
  coords: string;
  chamber: { id: string; brand: string; model: string };
  id_convention: string;
  bounds: { width: number; depth: number; height: number; interior: { width: number; depth: number; height: number; floor: number }; rackFront: number; rackBack: number; openingTop: number };
  /** Batas alat menurut brosur FPG450. */
  spec: Record<string, unknown>;
  doors: Record<string, { pivot: [number, number, number]; nodes: string[]; open_deg: number }>;
  shelves: SeedShelfRecord[];
  slots: SeedSlotRecord[];
  objects: ChamberObjectRecord[];
}
export interface ChamberReading { label: string; value: number; unit: string; d: number; }

/** Bacaan harus sinkron. `germinated` dibagi `seedCount` mengatur banyaknya bibit yang tampak. `trayColor` berisi kunci TRAY_COLORS atau angka warna. */
export interface SeedChamberProvider {
  getSlot(id: string): { state: SeedStateKey; seedCount?: number; germinated?: number; trayColor?: string | number; [k: string]: unknown } | undefined;
  lamps: { get(id: string): boolean | undefined };
  /** Ditampilkan pada layar alat di model. Tiga nilai pertama yang dipakai. */
  readings?(): Record<string, ChamberReading>;
}

export type ChamberViewName = 'overview' | 'inside';
export type ChamberSelection = { kind: 'slot' | 'object'; id: string };
export interface ChamberOptionsState {
  /** Kedua pintu terbuka. Mengisinya membuka atau menutup keduanya. */
  doorsOpen: boolean;
  /** Menutup pintu besi juga menutup pintu kaca. */
  outerDoorOpen: boolean;
  /** Membuka pintu kaca juga membuka pintu besi. */
  glassDoorOpen: boolean;
  /** Warnai nampan menurut status, bukan warna aslinya. */
  statusColors: boolean;
  realLight: boolean;
  highQuality: boolean;
}
export interface ChamberEvents {
  select: ChamberSelection | null;
  hover: ChamberSelection | null;
  view: ChamberViewName;
  filter: { shelf: number };
  options: ChamberOptionsState;
}
export interface CreateChamberOptions<P extends SeedChamberProvider = SeedChamberProvider> {
  /** Elemen pembungkus. Harus punya tinggi; kanvas mengisi seluruh elemen. */
  container: HTMLElement;
  /** URL folder berisi seed_chamber.glb dan seed_chamber_manifest.json. */
  assetsUrl?: string | URL;
  modelUrl?: string;
  manifestUrl?: string;
  /** Bawaan: SimulatedChamberProvider, yaitu data contoh. */
  provider?: P | ((manifest: ChamberManifest) => P);
  slotStates?: Record<string, SeedStateStyle>;
  quality?: 'auto' | boolean;
  tooltip?: boolean;
}
export interface SeedChamberScene<P extends SeedChamberProvider = SeedChamberProvider> {
  readonly manifest: ChamberManifest;
  readonly provider: P;
  readonly slotStates: Record<string, SeedStateStyle>;
  readonly selected: ChamberSelection | null;
  readonly filter: { shelf: number };
  readonly view: ChamberViewName;
  readonly options: ChamberOptionsState;
  setView(name: ChamberViewName): void;
  /** Dekatkan kamera ke satu rak dan buka pintu. 0 berarti semua. false bila rak tidak dikenal. */
  setFilter(filter: { shelf?: number }): boolean;
  setOptions(options: Partial<ChamberOptionsState>): void;
  /** false bila ID tidak dikenal. */
  select(selection: ChamberSelection | null): boolean;
  /** Tampilkan raknya lalu pilih posisinya. false bila ID tidak dikenal. */
  focusSlot(id: string): boolean;
  refreshSlot(id: string): boolean;
  /** Baca ulang posisi semai, lampu, dan layar alat dari provider. */
  refresh(): void;
  on<K extends keyof ChamberEvents>(type: K, fn: (payload: ChamberEvents[K]) => void): () => void;
  dispose(): void;
  three: {
    THREE: typeof THREE;
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    renderer: THREE.WebGLRenderer;
    controls: unknown;
    composer: unknown;
    gtao: unknown;
    nodes: Map<string, THREE.Object3D>;
    perf: { avgMs: number };
  };
}
export function createSeedChamberScene<P extends SeedChamberProvider = SeedChamberProvider>(options: CreateChamberOptions<P>): Promise<SeedChamberScene<P>>;

export class SimulatedChamberProvider implements SeedChamberProvider {
  constructor(manifest: ChamberManifest);
  slots: Map<string, { state: SeedStateKey; trayColor: string; batch: string; crop: string; sownOn: string; seedCount: number; germinated: number; transplantOn: string; note: string }>;
  lamps: Map<string, boolean>;
  getSlot(id: string): { state: SeedStateKey; trayColor: string; batch: string; crop: string; sownOn: string; seedCount: number; germinated: number; transplantOn: string; note: string } | undefined;
  updateSlot(id: string, patch: Record<string, unknown>): void;
  setLamp(id: string, on: boolean): void;
  readings(t?: number): Record<'suhu' | 'rh' | 'lux', ChamberReading>;
}
